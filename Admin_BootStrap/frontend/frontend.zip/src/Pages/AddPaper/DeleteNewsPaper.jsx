import React from 'react'

function DeleteNewsPaper() {
  return (
    <div>DeleteNewsPaper</div>
  )
}

export default DeleteNewsPaper